<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php

  echo "my first php page text file <br/>";

  
  

  echo str_word_count ("hello world");



  $str = "Hello World!";

  echo count_chars($str,3);



   $myfile = fopen("webdictionary.txt", "r") or die("Unable to open file!");
   echo fread($myfile,filesize("webdictionary.txt"));
   fclose($myfile);

    echo str_replace("world","Peter","Hello world!");


    if(file_exists("webdictionary.txt")) {
        $myfile = fopen("webdictionary.txt","r");
      } else {
        die("Error: The file does not exist.");
      }


   

  ?>

</body>
</html>